package com.org.WithdrawAccount;

import com.Account.org.Account;

public class CurrentAccount extends Account{
private int overdraftLimit;

public int getOverdraftLimit() {
	System.out.println("OverDraft Limit:"+overdraftLimit);
return overdraftLimit;
	}

public void setOverdraftLimit(int overdraftLimit) {
	this.overdraftLimit = overdraftLimit;
}
}
