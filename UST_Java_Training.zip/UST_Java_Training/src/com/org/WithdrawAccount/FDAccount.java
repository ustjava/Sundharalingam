package com.org.WithdrawAccount;

import java.util.Calendar;
import java.util.Date;

import com.Account.org.Account;
import com.org.interestCalculator.InterestCalculator;

public class FDAccount extends Account implements Renewable {

	
	public int getTenture() {
		System.out.println("Tenture:"+tenture+"Years");
		return tenture;
	}
	public void setTenture(int tenture) {
		this.tenture = tenture;
	}
	public String getAutoRenewal() {
		System.out.println("AutoRenuwal :"+autoRenewal);
		return autoRenewal;
	}
	public void setAutoRenewal(String autoRenewal) {
		this.autoRenewal = autoRenewal;
	}
	private int tenture;
	private String autoRenewal;
	private float FDAmount;
	private float ratio;
	private Date maturityDate;
	
	public Date getMaturityDate() {
		System.out.println("Maturity Date:"+maturityDate);
		return maturityDate;
	}
	public void setMaturityDate(Date dateSpecified) {
		
		this.maturityDate = dateSpecified;
	}
	private InterestCalculator interestcalculator=new InterestCalculator(); 
	public float getRatio() {
		System.out.println("Ratio:"+ratio+"%");
		return ratio;
	}
	public void setRatio(double d) {
		this.ratio = (float) d;
	}
	public float getFDAmount() {
		System.out.println("FD Amount:"+FDAmount);
		return FDAmount;
	}
	public void setFDAmount(float fDAmount) {
		FDAmount = fDAmount;
	}
	public void interestCalculator() {
		float interest=interestcalculator.intrestCalculate(FDAmount, tenture, ratio);;
		System.out.println("FD Simple Interest:"+interest);
		System.out.println("Total:"+(interest+FDAmount));
	}
	@Override
	public void autoRenewal(int tenuree) {
		if (autoRenewal=="Yes") {
			Calendar c = Calendar.getInstance();

			// set the calendar to start of today
			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			c.set(Calendar.MILLISECOND, 0);

			// and get that as a Date
			Date today = c.getTime();
			if (maturityDate.before(today)) {
				System.out.println("True");
			}
			else {
				System.out.println("AutoRewal:"+"Yes");	// TODO Auto-generated method stub
				System.out.println("tenuree:"+tenuree+"years");	// TODO Auto-generated method stub
				System.out.println("Maturity Date not yet Arraived");
				c.add(Calendar.YEAR, tenuree);
				System.out.println("Maturity Date:"+c.getTime());
			}
			
				
		}else {
			System.out.println("AutoRewal:"+"No");	// TODO Auto-generated method stub
			System.out.println("tenuree:"+tenuree+"years");	// TODO Auto-generated method stub
			
		}
			
	}
	
}
